// Schema-check every content module + config file, plus the pipeline invariants
// the build package calls out ("did you break the format, did you forget to bump
// content_version").
import Ajv from "ajv/dist/2020.js";
import { basename, join } from "node:path";
import { createHash } from "node:crypto";
import { readFileSync, existsSync } from "node:fs";
import {
  loadModules,
  loadConfig,
  loadAllSchemas,
  SCHEMA_FOR_TYPE,
  CONTENT_DIR,
} from "./lib/content.mjs";

const ajv = new Ajv({ allErrors: true, strict: false });
for (const [, schema] of await loadAllSchemas()) ajv.addSchema(schema);

const errors = [];
const warnings = [];
const MAX_LIST_DEPTH = 3;

/**
 * Deepest list nesting reachable from each list in `node`, with a path to it.
 * Walks the whole module rather than only known list fields, so it covers
 * reference/peds `body[].items`, procedure `nodes[].substeps.items`, and
 * anything later that reuses `$defs/listItem`.
 */
function listDepths(node, path = "") {
  const out = [];
  const measure = (items) =>
    1 +
    Math.max(
      0,
      ...items.map((it) =>
        it && typeof it === "object" && Array.isArray(it.items)
          ? measure(it.items)
          : 0,
      ),
    );

  const walk = (value, at) => {
    if (Array.isArray(value)) {
      value.forEach((v, i) => walk(v, `${at}[${i}]`));
      return;
    }
    if (!value || typeof value !== "object") return;
    for (const [k, v] of Object.entries(value)) {
      if (k === "items" && Array.isArray(v)) {
        out.push({ path: `${at}/items`, depth: measure(v) });
      }
      walk(v, `${at}/${k}`);
    }
  };

  walk(node, path);
  return out;
}

/** Every `diagram` object anywhere in a module, with a path to it. */
function findDiagrams(node, path = "") {
  const out = [];
  const walk = (v, at) => {
    if (Array.isArray(v)) return v.forEach((x, i) => walk(x, `${at}[${i}]`));
    if (!v || typeof v !== "object") return;
    for (const [k, x] of Object.entries(v)) {
      if (k === "diagram" && x && typeof x === "object") out.push({ path: `${at}/diagram`, diagram: x });
      walk(x, `${at}/${k}`);
    }
  };
  walk(node, path);
  return out;
}

const fail = (where, msg) => errors.push(`✗ ${where}: ${msg}`);
const warn = (where, msg) => warnings.push(`! ${where}: ${msg}`);

function validateAgainst(schemaFile, data, where) {
  const validate = ajv.getSchema(`https://kairos.app/schema/${schemaFile}`);
  if (!validate) return fail(where, `no schema loaded for ${schemaFile}`);
  if (!validate(data)) {
    for (const e of validate.errors) fail(where, `${e.instancePath || "/"} ${e.message}`);
  }
}

// ---- config files ----------------------------------------------------------
validateAgainst("config.sections.schema.json", await loadConfig("sections.json"), "config/sections.json");
validateAgainst("config.weight-zones.schema.json", await loadConfig("weight-zones.json"), "config/weight-zones.json");
validateAgainst("config.tiers.schema.json", await loadConfig("tiers.json"), "config/tiers.json");
validateAgainst("config.settings.schema.json", await loadConfig("settings.json"), "config/settings.json");
const pinnedCfg = await loadConfig("pinned.json").catch(() => null);
if (pinnedCfg) validateAgainst("config.pinned.schema.json", pinnedCfg, "config/pinned.json");

const sectionsCfg = await loadConfig("sections.json");
const knownCategories = new Set(
  sectionsCfg.sections.flatMap((s) => s.categories.map((c) => c.title))
);
// { "Section Title" -> Set(category titles) } for crossListIn validation
const catsBySection = new Map(
  sectionsCfg.sections.map((s) => [s.title, new Set(s.categories.map((c) => c.title))])
);

// ---- modules --------------------------------------------------------------
const mods = await loadModules();
if (mods.length === 0) fail("content/modules", "no module JSON files found");

const seenIds = new Set();

for (const mod of mods) {
  const where = mod.relPath;
  const { json } = mod;

  const schemaFile = SCHEMA_FOR_TYPE[json.contentType];
  if (!schemaFile) {
    fail(where, `unknown contentType "${json.contentType}"`);
    continue;
  }

  // Decouple a peds-tool's embeddedCalculator: validate it on its own against the
  // calculator schema, then validate the wrapper without it. Nesting two
  // `unevaluatedProperties: false` schemas via $ref is an ajv performance cliff.
  if (json.contentType === "peds-tool" && json.embeddedCalculator) {
    validateAgainst("calculator.schema.json", json.embeddedCalculator, `${where} › embeddedCalculator`);
    const { embeddedCalculator, ...rest } = json;
    validateAgainst(schemaFile, rest, where);
  } else {
    validateAgainst(schemaFile, json, where);
  }

  // filename == id
  if (json.id && basename(mod.key) !== json.id) {
    fail(where, `id "${json.id}" does not match filename "${basename(mod.key)}.json"`);
  }

  // unique id
  if (json.id) {
    if (seenIds.has(json.id)) fail(where, `duplicate id "${json.id}"`);
    seenIds.add(json.id);
  }

  // section matches the directory it lives in
  if (mod.expectedSection && json.section !== mod.expectedSection) {
    fail(where, `section "${json.section}" but lives under modules/${mod.topDir}/ (expected "${mod.expectedSection}")`);
  }

  // category is one the sections config knows about
  if (json.category && !knownCategories.has(json.category)) {
    warn(where, `category "${json.category}" is not listed in config/sections.json`);
  }

  // crossListIn targets must be real {section, category} pairs, and not the home section
  for (const x of json.crossListIn || []) {
    const cats = catsBySection.get(x.section);
    if (!cats) fail(where, `crossListIn section "${x.section}" is not a known section`);
    else if (!cats.has(x.category)) fail(where, `crossListIn "${x.section}" has no category "${x.category}"`);
    if (x.section === json.section) fail(where, `crossListIn repeats the module's own section "${x.section}" — that's its home, not a cross-list`);
  }

  // content_version bump discipline
  if (Array.isArray(json.changelog) && json.changelog.length > 0) {
    const latest = Math.max(...json.changelog.map((c) => c.version));
    if (latest !== json.content_version) {
      fail(where, `content_version is ${json.content_version} but newest changelog entry is v${latest} — bump content_version (or add the changelog entry) before shipping`);
    }
  } else {
    warn(where, "no changelog[] — add one so 'why does this say X' has an answer");
  }

  // tiered content must carry review metadata (belt-and-suspenders over the schema)
  if (typeof json.review_tier === "number") {
    for (const f of ["last_reviewed", "next_review_due", "sources"]) {
      if (!json[f] || (Array.isArray(json[f]) && json[f].length === 0)) {
        fail(where, `review_tier ${json.review_tier} requires "${f}"`);
      }
    }
  }
  if (json.review_tier === undefined) {
    warn(where, "no review_tier — set one (1/2/3 or \"stable\") so the staleness tripwire knows what to do");
  }

  // List nesting depth. JSON Schema can express the recursion but not a cap on
  // it, so the cap lives here. Three levels is the readability ceiling on a
  // phone at arm's length; past that the content wants a table or its own
  // section, not more indentation.
  // Diagram background plates: the file must exist, and must be the file the
  // credit says it is. A plate swapped for a different image — or corrupted by
  // a sync client — would still render, just as the wrong anatomy under a
  // correctly-registered overlay. The checksum is what catches that.
  for (const { path, diagram } of findDiagrams(json)) {
    const img = diagram.image;
    if (!img) continue;
    const file = join(CONTENT_DIR, img.src);
    if (!existsSync(file)) {
      fail(where, `${path}/image: ${img.src} does not exist under content/`);
      continue;
    }
    if (img.sha1) {
      const actual = createHash("sha1").update(readFileSync(file)).digest("hex");
      if (actual !== img.sha1) {
        fail(where, `${path}/image: ${img.src} sha1 is ${actual}, expected ${img.sha1} — the file on disk is not the one credited`);
      }
    }
  }

  for (const { path, depth } of listDepths(json)) {
    if (depth > MAX_LIST_DEPTH) {
      fail(where, `${path} nests lists ${depth} deep (max ${MAX_LIST_DEPTH}) — use a table or a separate step instead of deeper indentation`);
    }
  }
}

// pinned shortcuts must point at real modules
for (const p of pinnedCfg?.pinned || []) {
  if (!seenIds.has(p.id)) fail("config/pinned.json", `pinned id "${p.id}" is not a module`);
}

// ---- report -------------------------------------------------------------
for (const w of warnings) console.warn(w);
console.log(`\nvalidate: ${mods.length} modules, ${errors.length} errors, ${warnings.length} warnings`);
if (errors.length) {
  console.error("\n" + errors.join("\n"));
  process.exit(1);
}
console.log("✓ all content valid");
