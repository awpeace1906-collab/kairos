// Offline-first service worker. Precache the app shell + the bundled content tree
// so a first launch with no connectivity still works (Content Update Architecture
// spec, fallback #4). OTA content updates land in a separate runtime cache managed
// by ContentStore; this SW just guarantees the shell and the bundled baseline.

const SHELL_CACHE = "kairos-shell-v16";
const SHELL = [
  "./",
  "./index.html",
  "./styles.css",
  "./manifest.webmanifest",
  "./public/icons/icon.svg",
  "./public/fonts/IBMPlexSans-Regular.ttf",
  "./public/fonts/IBMPlexSans-Medium.ttf",
  "./public/fonts/IBMPlexSans-SemiBold.ttf",
  "./public/fonts/IBMPlexSans-Bold.ttf",
  "./public/fonts/IBMPlexMono-Regular.ttf",
  "./public/fonts/IBMPlexMono-Medium.ttf",
  "./public/fonts/IBMPlexMono-SemiBold.ttf",
  "./src/main.js",
  "./src/components.js",
  "./src/lib/contentStore.js",
  "./src/lib/router.js",
  "./src/lib/search.js",
  "./src/lib/expr.js",
  "./src/lib/calcEngine.js",
  "./src/lib/weightZones.js",
  "./src/lib/session.js",
  "./src/lib/prefs.js",
  "./src/lib/settingLens.js",
  "./src/lib/appConfig.js",
  "./src/lib/richText.js",
  "./src/lib/axisEngine.js",
  "./src/views/home.js",
  "./src/views/section.js",
  "./src/views/content.js",
  "./src/views/calculator.js",
  "./src/views/prose.js",
  "./src/views/axisTool.js",
  "./src/views/settings.js",
  "./src/views/about.js",
  "./src/views/disclaimer.js",
  "./src/views/acknowledgments.js",
  "./src/views/sources.js",
  "./content/manifest.json",
  "./content/search-index.json",
  "./content/sources-index.json",
  "./content/config/sections.json",
  "./content/config/weight-zones.json",
  "./content/config/tiers.json",
  "./content/config/settings.json",
  "./content/config/pinned.json",
];

self.addEventListener("install", (e) => {
  e.waitUntil(
    (async () => {
      const cache = await caches.open(SHELL_CACHE);
      await cache.addAll(SHELL);
      // Precache every content module listed in the manifest, so a first-ever
      // offline visit to any item still works (not just the app shell).
      try {
        const manifest = await (await fetch("./content/manifest.json", { cache: "no-cache" })).json();
        const paths = Object.values(manifest.modules).map((m) => "./content/" + m.path);
        // Diagram background plates too — otherwise a plate reaches the cache
        // only after someone views it online, and a first offline visit to
        // that procedure shows the overlay with nothing under it.
        const assets = Object.keys(manifest.assets || {}).map((a) => "./content/" + a);
        await Promise.allSettled([...paths, ...assets].map((p) => cache.add(p)));
      } catch { /* offline at install time — the shell is still cached */ }
      await self.skipWaiting();
    })()
  );
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== SHELL_CACHE && !k.startsWith("kairos-content")).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (e) => {
  const { request } = e;
  if (request.method !== "GET") return;
  const url = new URL(request.url);
  if (url.origin !== location.origin) return;

  // Content JSON: cache-first, refresh in the background (stale-while-revalidate).
  if (url.pathname.includes("/content/")) {
    e.respondWith(
      caches.open(SHELL_CACHE).then(async (cache) => {
        const cached = await cache.match(request);
        const network = fetch(request)
          .then((res) => {
            if (res.ok) cache.put(request, res.clone());
            return res;
          })
          .catch(() => cached);
        return cached || network;
      })
    );
    return;
  }

  // App shell: cache-first, fall back to network.
  e.respondWith(caches.match(request).then((c) => c || fetch(request)));
});
