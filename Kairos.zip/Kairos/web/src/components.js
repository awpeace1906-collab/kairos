// Small DOM helpers + the Tier 6 UI affordances.

import { flagOutdatedURL } from "./lib/appConfig.js";
import { isPinned, togglePin } from "./lib/prefs.js";

/** A pin / unpin toggle for a module's detail view. Reflects state on click. */
export function pinButton(mod, store) {
  const curated = store.curatedPinIds;
  const render = (on) => {
    btn.className = "pin-btn" + (on ? " on" : "");
    btn.textContent = on ? "★ Pinned" : "☆ Pin";
    btn.setAttribute("aria-pressed", String(on));
  };
  const btn = el("button", {
    type: "button",
    onClick: () => render(togglePin(mod.id, curated)),
  });
  render(isPinned(mod.id, curated));
  return btn;
}

export function el(tag, props = {}, ...children) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === "class") node.className = v;
    else if (k === "dataset") Object.assign(node.dataset, v);
    else if (k.startsWith("on") && typeof v === "function") node.addEventListener(k.slice(2).toLowerCase(), v);
    else if (v != null && v !== false) node.setAttribute(k, v === true ? "" : v);
  }
  mount(node, ...children);
  return node;
}

/** Append children, skipping null/false/undefined (native .append stringifies them). */
export function mount(parent, ...children) {
  for (const c of children.flat(Infinity)) {
    if (c == null || c === false || c === true) continue;
    parent.append(c.nodeType ? c : document.createTextNode(String(c)));
  }
  return parent;
}

/** Tier 6: iOS-style inline clear ("x in a circle") that clears just this field. */
export function clearableField({ id, label, unit, type = "number", value = "", min, max, onInput, onClear }) {
  const input = el("input", {
    id,
    type,
    inputmode: type === "number" ? "decimal" : null,
    value: value ?? "",
    min,
    max,
    onInput: (e) => onInput?.(e.target.value),
  });
  const clearBtn = el(
    "button",
    {
      type: "button",
      class: "clear-field",
      "aria-label": `Clear ${label}`,
      hidden: !String(value ?? "").length,
      onClick: () => {
        input.value = "";
        clearBtn.hidden = true;
        onClear?.();
        onInput?.("");
        input.focus();
      },
    },
    "✕"
  );
  input.addEventListener("input", () => {
    clearBtn.hidden = !input.value.length;
  });
  return el(
    "label",
    { class: "field" },
    el("span", { class: "field-label" }, label, unit ? el("span", { class: "unit" }, ` (${unit})`) : null),
    el("span", { class: "field-input" }, input, clearBtn)
  );
}

/** Tier 6: one button that clears every field on a multi-field screen. */
export function clearFieldsButton(onClick) {
  return el("button", { type: "button", class: "clear-all", onClick }, "Clear fields");
}

/** "Last verified" line + human-sourced staleness channel (Content Update spec §3).
    "Flag as outdated" opens a prefilled GitHub issue on the content repo. */
export function lastVerified(mod) {
  if (!mod.last_reviewed) return null;
  const d = new Date(mod.last_reviewed + "T00:00:00Z");
  const stamp = d.toLocaleDateString(undefined, { month: "short", year: "numeric" });
  return el(
    "p",
    { class: "last-verified" },
    `Last verified ${stamp}`,
    " · ",
    el("a", { href: flagOutdatedURL(mod), target: "_blank", rel: "noopener" }, "Flag as outdated")
  );
}

export function severityClass(sev) {
  return sev ? `sev-${sev}` : "";
}

/** mod.section is the human title ("Procedures", "Drug & Dosing Cards", ...);
    map it to the matching --sec-* token from styles.css so every content page
    (not just the home tiles) carries its section's tint as a top border. */
const SECTION_TINT_VAR = {
  "Procedures": "--sec-procedures",
  "Calculators": "--sec-calculators",
  "Drug & Dosing Cards": "--sec-drug-dosing",
  "Reference Library": "--sec-reference-library",
  "Peds Module": "--sec-peds-module",
};
export function tintStyle(mod) {
  return tintStyleForSection(mod.section);
}
export function tintStyleForSection(sectionTitle) {
  const v = SECTION_TINT_VAR[sectionTitle];
  return v ? `--tint: var(${v})` : null;
}

/** Numbered, always-visible list of the primary sources for this page's material.
    Pass 1 renders the raw `sources[]` strings; a structured citation registry
    (content/config/citations.json) replaces the free text in a later pass. */
export function sourcesBlock(mod) {
  if (!mod.sources?.length) return null;
  return el(
    "section",
    { class: "sources-block" },
    el("h2", {}, "Sources"),
    el("ol", {}, mod.sources.map((s) => el("li", {}, s))),
    el("p", { class: "sources-all" }, el("a", { href: "#/sources" }, "All sources ›"))
  );
}
